#!/bin/bash

read num1
read num2
sum=$(($num1+$num2))
echo $num1 + $num2 = $sum
