#!/bin/bash

array=(A B C D E F) 
echo ${array[*]}
echo ${array[2]}
echo ${#array[*]}
echo
echo for loop:
for chr in ${array[@]}; do
 echo $chr 
done 
