#!/bin/bash

num1=1
num2=2
echo [$num1 -lt $num2]
echo $?
echo [$num1 -gt $num2]
echo $?
echo [$num1 -eq $num2]
echo $?
echo [$num1 -ne $num2`]
echo $?


