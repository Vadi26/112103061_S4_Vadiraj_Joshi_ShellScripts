#!/bin/bash
[ "github" = "gitlab" ]
echo $?

str1="github"
str2="gitlab"
echo comparing strings stored in variables:
[ $str1 = $str2 ]
echo $?
