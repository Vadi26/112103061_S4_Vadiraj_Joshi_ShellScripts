#!/bin/bash

string_UNIX="UNIX"
string_GNU="GNU"
echo "Are $string_a and $string_b strings equal?" [ $string_a = $string_b ]
echo $?
