#!/bin/bash

a=16 
if ((a==16))
    then 
        echo "yes , It is equal to 16"
    else
        echo "no , It is not equal to 16"
fi

if (( (a-5) == 0 ))
    then
        echo "yes, It is equal to 5"
    else 
        echo "no, It is not equal to 5"
fi

if (( a < 10  ))
    then
        echo "yes, It is smaller than 10"  
    else
    echo "No, it is not smaller than 10"
fi

if (( a == 16 || a == 4*4  ))
    then
        echo yes  
    else
        echo no
fi

