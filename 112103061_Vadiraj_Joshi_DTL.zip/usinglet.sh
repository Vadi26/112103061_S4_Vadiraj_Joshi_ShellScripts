#!/bin/bash

let x=1+3
let y=7*10
let z=16/4
let w=5-683

echo $a $b $c $d
