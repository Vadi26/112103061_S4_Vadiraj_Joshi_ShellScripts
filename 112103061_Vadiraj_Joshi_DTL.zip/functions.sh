#!/bin/bash

function func1 {
        echo This is function 1
}

function func2 { 
        echo This is function 2 which will add two numbers x and y
        read x
        read y
        echo "Sum is $((x+y))"
}


function func3 () { 
        echo This is function 3 which multilpies two numbers x and y
        read x
        read y
        echo "Product is $((x*y))"
}

func3
func2
func1
