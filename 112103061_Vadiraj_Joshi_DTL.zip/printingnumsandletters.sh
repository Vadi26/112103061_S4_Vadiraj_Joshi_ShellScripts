#!/bin/bash

echo a{b,c,d}e     
echo
echo {A..Z}           # Prints letter from A to Z
echo
mkdir z{1..3}       # Creates files named zi where i is the number
ls
