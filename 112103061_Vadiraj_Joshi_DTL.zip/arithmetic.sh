#!/bin/bash

num=4
num2=8
echo $((num = num+num2))
echo $num
((num++))
echo num++ = $num
((num--))
echo num-- = $num
