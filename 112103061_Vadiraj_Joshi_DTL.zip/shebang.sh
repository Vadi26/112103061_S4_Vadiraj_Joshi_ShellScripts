#!/bin/bash

echo 'This is written for script execution using SheBang (#!)'
