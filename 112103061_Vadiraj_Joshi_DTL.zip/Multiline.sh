echo adding a new line
echo This is the second line
echo You have reached the third line
